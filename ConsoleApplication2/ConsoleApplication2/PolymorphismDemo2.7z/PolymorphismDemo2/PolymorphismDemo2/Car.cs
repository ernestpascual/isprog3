﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo2
{
    public abstract class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public string PlateNumber { get; set; }

        public virtual void StartCar() {
            Console.WriteLine("Staring car");
        }
        public virtual void StopCar() {
            Console.WriteLine("Stopping car");
        }
    }
}
