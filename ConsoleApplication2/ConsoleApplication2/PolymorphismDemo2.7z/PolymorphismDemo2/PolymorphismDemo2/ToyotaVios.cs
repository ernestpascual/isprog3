﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo2
{
    public class ToyotaVios : Car
    {
        public override void StartCar()
        {
            Console.WriteLine("Starting Toyota Vios... broom broom");
        }
    }

    public class Vios2ndGen : ToyotaVios
    {

    }
}
