﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new ToyotaVios();
            Car car2 = new FordExplorer();
            StartMe(car1);
            StartMe(car2);

            var radio1 = new CarRadio<ToyotaVios>();
            radio1.Car = (ToyotaVios)car1;
            radio1.Car.StartCar();

            ToyotaVios[] t = new ToyotaVios[5];
            for(int i = 0; i < 5; i++)
            {
                t[i] = new ToyotaVios();
            }

            foreach(ToyotaVios tv in t)
            {
                tv.StartCar();
            }

            int[] nums = { 1, 2, 3, 4, 5 };
            foreach(int x in nums)
            {
                Console.WriteLine(x);
            }

            Console.WriteLine((car1 is ToyotaVios) ? "I'm Toyota" : "I'm Ford");
            Console.WriteLine((car2 is ToyotaVios) ? "I'm Toyota" : "I'm Ford");

            //var car3 = (ToyotaVios)car2;
            var car3 = car1 as ToyotaVios;
            Console.WriteLine(car3);
        }

        public static void StartMe(Car anyCar)
        {
            anyCar.StartCar();
        }
    }

    class Test
    {
        public void MyTest()
        {

            Program.StartMe(new ToyotaVios());
        }
    }
}
