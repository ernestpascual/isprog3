﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo2
{
    class CarRadio<X> where X : Car
    {
        public X Car { get; set; }

        public void StartRadio()
        {
            Car.StartCar();
            Console.WriteLine("Starting radio");
        }
    }
}
